package com.example.firstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.test1.R;

public class MainActivity extends AppCompatActivity {
    EditText Name ;
    //EditText Prenom ;
    Button CH;
    TextView msg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Name=(EditText)findViewById(R.id.Name);
        //Prenom = (EditText)findViewById(R.id.pn);
        CH=(Button)findViewById(R.id.button);
        msg=(TextView)findViewById(R.id.msg);

        CH.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = Name.getText().toString();
                //String Prenom=Prenom.getText().toString();
                msg.setText("Bonjour "+name);

            }
        });
    }
}